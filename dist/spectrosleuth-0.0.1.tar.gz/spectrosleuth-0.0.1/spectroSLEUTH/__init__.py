print("spectroSLEUTH installed: beta version")
