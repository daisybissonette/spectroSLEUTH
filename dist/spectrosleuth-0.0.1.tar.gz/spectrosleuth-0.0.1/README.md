# spectroSLEUTH
SpectroSLEUTH: SpectroScopy Line Emission Utility and Tracking Helper

A 2024 CodeAstro Workshop Project (Group #2)
